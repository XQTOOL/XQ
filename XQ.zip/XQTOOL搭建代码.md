##安装过程
###需要先给termuxAPP所有文件访问权限
## termux 输入以下命令
#⚠️不管你之前有没有执行过以下命令，现在都必须执行
```
apt upgrade
```
```
pkg install git
```
```
rm -rf $HOME/XQTOOL
```
```
git clone https://github.com/XQTOOL/XQ
```
```
(以上步骤建议打开VPN执行命令，否则无法下载XQ文件)
```
```
cd XQTOOL
```
```
chmod +x setup
```
```
bash setup
```
## Start code
```
cd XQTOOL
```
```
bash xq 或者 ./xq
```